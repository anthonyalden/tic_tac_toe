// global variables
        angular.module('ticTacToeApp', ['firebase']);

        